import "./SearchContact.css";
import { BiSearch } from "react-icons/bi";
import { FaMicrophone } from "react-icons/fa";
import { useState } from "react";
const SearchContact = ({ contacts, setContacts }) => {
  const [value, setValue] = useState("");
  const changeHandler = (e) => {
    console.log(e.target.value);
    setValue(e.target.value);
  };
  return (
    <div className="searchBox">
      <BiSearch />
      <input
        type="search"
        name="searchContact"
        placeholder="Search"
        onChange={changeHandler}
        value={value}
      />
      <FaMicrophone />
    </div>
  );
};

export default SearchContact;
