import { Link } from "react-router-dom";
import "./contact.css";
const Contact = ({ contact, onDelete }) => {
  const { name, lastname, id } = contact;

  return (
    <div>
      <Link
        to={{
          pathname: `user/${id}`,
          state: { contact: contact },
        }}
        className="contact"
        onDelete={onDelete}
      >
        <p style={{ margin: "0 5px 0 0", textTransform: "capitalize" }}>
          {name}
        </p>
        <p style={{ fontWeight: "bold", textTransform: "capitalize" }}>
          {lastname}
        </p>
      </Link>
      <hr />

      <button onClick={() => onDelete(id)}>Delete contact</button>
    </div>
  );
};

export default Contact;
