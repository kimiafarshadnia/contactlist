import KeyPadComponent from "./../components/Keypad/KeyPadComponent";

const KeyPad = () => {
  return (
    <main className="mainPages">
      <KeyPadComponent />
    </main>
  );
};

export default KeyPad;
