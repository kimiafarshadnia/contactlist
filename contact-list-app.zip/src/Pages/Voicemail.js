const Voicemail = () => {
  return (
    <main className="mainPages">
      <h1>Voicemail</h1>

      <div className="voicemail">
        <button className="btnVoicemail">Call Voicemail</button>
      </div>
    </main>
  );
};

export default Voicemail;
