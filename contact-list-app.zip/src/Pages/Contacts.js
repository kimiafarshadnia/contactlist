import ContactList from "../components/ContactList/ContactList";
import MyCard from "../components/MyCard/MyCard";
import SearchContact from "../components/SearchContact/SearchContact";
import AddContact from "../components/AddContact/Addconatct";
import { useState, useEffect } from "react";

import getContacts from "../services/getContactsService";
import deleteOneContact from "./../services/deleteContactService";
import addOneContact from "./../services/addContactService";
import EditContact from "./../components/EditContact/EditContact";
const Contacts = () => {
  const [contacts, setContacts] = useState([]);

  const addContactHandler = async (contact) => {
    try {
      const { data } = await addOneContact(contact);
      setContacts([...contacts, data]);
    } catch (error) {}
  };

  const deleteContactHandler = async (id) => {
    try {
      const filteredContacts = contacts.filter((c) => c.id !== id);
      setContacts(filteredContacts);
      await deleteOneContact(id);
    } catch (error) {}
  };

  useEffect(() => {
    const fetchContacts = async () => {
      const { data } = await getContacts();
      setContacts(data);
    };
    try {
      fetchContacts();
    } catch (error) {}
  }, []);

  return (
    <main style={{ padding: "0.75rem" }}>
      <h1>Contacts</h1>
      <SearchContact contacts={contacts} setContacts={setContacts} />
      <hr />
      <MyCard />
      <AddContact addContactHandler={addContactHandler} />
      <hr />
      <ContactList contacts={contacts} onDelete={deleteContactHandler} />
    </main>
  );
};

export default Contacts;
