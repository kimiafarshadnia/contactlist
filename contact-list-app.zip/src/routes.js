// import Favorites from "./pages/Favorites";
// import Contacts from "./pages/Contacts";
// import Recents from "./pages/Recents";
// import NotFound from "./pages/NotFound";
// import KeypadPage from "./Pages/KeypadPage";
// import Voicemail from "./pages/Voicemail";

// const routes = [
//   { path: "/recents", component: Recents },
//   { path: "/", component: Contacts, exact: true },
//   { path: "/keypad", component: KeypadPage },
//   { path: "/voicemail", component: Voicemail },
//   { path: "/favorites", component: Favorites },
//   { component: NotFound },
// ];

// export default routes;
